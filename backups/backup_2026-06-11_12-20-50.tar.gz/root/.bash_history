su sam
cd
vim /etc/sudoers
su
cd
subscription-manager register 
yum install python3 -y
yum install python3 -y --nogpgcheck
su sam
cd
ls
useradd sam
ip a
hostname
passwd sam
su sam
cd
vim /etc/hosts
su
su sam
cd
clear
cd
ip a
clear
cd
vim /etc/sudoers
su sam
cd
subscription-manager register 
su sam
cd
ls
su sam 
